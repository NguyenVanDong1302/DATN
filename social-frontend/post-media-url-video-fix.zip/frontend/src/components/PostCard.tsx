import { useMemo, useState, type MouseEvent } from 'react'
import { resolveMediaUrl } from '../lib/api'
import { Post } from '../types'

function VideoPostMedia({ src }: { src: string }) {
  const [muted, setMuted] = useState(true)

  const togglePlayback = (event: MouseEvent<HTMLVideoElement>) => {
    const video = event.currentTarget
    if (video.paused) {
      void video.play().catch(() => undefined)
    } else {
      video.pause()
    }
  }

  return (
    <div style={{ position: 'relative' }}>
      <video
        src={resolveMediaUrl(src)}
        muted={muted}
        playsInline
        preload="metadata"
        controls={false}
        style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', background: '#000', display: 'block' }}
        onClick={togglePlayback}
      />
      <button
        type="button"
        className="btn"
        style={{ position: 'absolute', right: 10, bottom: 10, backdropFilter: 'blur(8px)' }}
        onClick={() => setMuted((prev) => !prev)}
      >
        {muted ? 'Bật âm thanh' : 'Tắt âm thanh'}
      </button>
    </div>
  )
}

export default function PostCard({
  post,
  onLike,
  onOpenComment,
  onOpenDetail,
  onOpenAuthor,
}: {
  post: Post
  onLike: () => void
  onOpenComment: () => void
  onOpenDetail: () => void
  onOpenAuthor: () => void
}) {
  const likesCount = post.displayLikesCount ?? post.likesCount ?? (Array.isArray(post.likes) ? post.likes.length : 0)
  const likedByMe = !!post.likedByMe
  const commentsCount = post.commentsCount ?? 0
  const viewsCount = post.viewsCount ?? 0

  const orderedMedia = useMemo(() => {
    const media = Array.isArray(post.media) ? [...post.media] : []
    media.sort((a, b) => (a.order || 0) - (b.order || 0))

    return media.map((item) => ({
      ...item,
      type: item.type === 'video' || item.mimeType?.startsWith('video/') ? 'video' : 'image',
      url: resolveMediaUrl(item.url),
    }))
  }, [post.media])

  const fallbackImageUrl = resolveMediaUrl(post.imageUrl)

  return (
    <div className="post">
      <div className="row">
        <strong style={{ cursor: 'pointer' }} onClick={onOpenAuthor}>
          @{post.authorUsername || post.authorId || 'user'}
        </strong>
        <span className="muted">{post.visibility || 'public'}</span>
        <span className="muted" style={{ marginLeft: 'auto' }}>
          {post.createdAt ? new Date(post.createdAt).toLocaleString() : ''}
        </span>
      </div>

      {post.content && <div style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{post.content}</div>}
      {orderedMedia.length ? (
        <div style={{ marginTop: 10, display: 'grid', gap: 8 }}>
          {orderedMedia.map((item, index) =>
            item.type === 'video' ? (
              <VideoPostMedia key={`${item.url}-${index}`} src={item.url} />
            ) : (
              <img
                key={`${item.url}-${index}`}
                src={item.url}
                alt={item.altText || 'image'}
                loading="lazy"
                style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', display: 'block' }}
              />
            ),
          )}
        </div>
      ) : fallbackImageUrl ? (
        <img
          src={fallbackImageUrl}
          alt="image"
          loading="lazy"
          style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', marginTop: 10, display: 'block' }}
        />
      ) : null}

      <div className="kpi">
        <button className="btn" onClick={onLike}>
          {likedByMe ? 'Unlike' : 'Like'} · {likesCount}
        </button>
        <button className="btn" onClick={onOpenComment}>
          Comment · {commentsCount}
        </button>
        <button className="btn" onClick={onOpenDetail} style={{ marginLeft: 'auto' }}>
          Detail
        </button>
      </div>
      <div className="muted" style={{ marginTop: 8 }}>
        {viewsCount} lượt xem
      </div>
    </div>
  )
}
