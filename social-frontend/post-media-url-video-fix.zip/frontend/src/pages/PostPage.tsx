import { useEffect, useMemo, useState, type MouseEvent } from 'react'
import { useParams } from 'react-router-dom'
import { resolveMediaUrl, useApi } from '../lib/api'
import { Post } from '../types'
import { useToast } from '../components/Toast'

function DetailVideo({ src }: { src: string }) {
  const [muted, setMuted] = useState(true)

  const togglePlayback = (event: MouseEvent<HTMLVideoElement>) => {
    const video = event.currentTarget
    if (video.paused) {
      void video.play().catch(() => undefined)
    } else {
      video.pause()
    }
  }

  return (
    <div style={{ position: 'relative', marginTop: 10 }}>
      <video
        src={resolveMediaUrl(src)}
        muted={muted}
        playsInline
        preload="metadata"
        controls={false}
        style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', background: '#000', display: 'block' }}
        onClick={togglePlayback}
      />
      <button
        type="button"
        className="btn"
        onClick={() => setMuted((value) => !value)}
        style={{ position: 'absolute', right: 10, bottom: 10 }}
      >
        {muted ? 'Bật âm' : 'Tắt âm'}
      </button>
    </div>
  )
}

export default function PostPage() {
  const { id = '' } = useParams()
  const api = useApi()
  const toast = useToast()

  const [post, setPost] = useState<Post | null>(null)
  const [loading, setLoading] = useState(false)
  const [text, setText] = useState('')
  const [status, setStatus] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const res = await api.get(`/posts/${id}`)
      setPost(res?.data?.post || res?.data || res)
    } catch (e: any) {
      toast.push(`Load lỗi: ${e.message}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (id) void load()
  }, [id])

  const orderedMedia = useMemo(() => {
    const media = Array.isArray(post?.media) ? [...post.media] : []
    media.sort((a, b) => (a.order || 0) - (b.order || 0))
    return media.map((item) => ({
      ...item,
      type: item.type === 'video' || item.mimeType?.startsWith('video/') ? 'video' : 'image',
      url: resolveMediaUrl(item.url),
    }))
  }, [post?.media])

  const send = async () => {
    const v = text.trim()
    if (!v) return
    setStatus('Sending...')
    try {
      await api.post(`/posts/${id}/comments`, { content: v })
      setText('')
      setStatus('Sent!')
      toast.push('Commented')
    } catch (e: any) {
      setStatus(e.message || 'Comment failed')
    }
  }

  return (
    <div className="card">
      <div className="row">
        <strong>Post detail</strong>
        <span className="muted">{id}</span>
        <button className="btn" style={{ marginLeft: 'auto' }} onClick={load}>
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      {!post && !loading && <div className="muted" style={{ marginTop: 10 }}>Post not found / forbidden</div>}

      {post && (
        <div style={{ marginTop: 10 }}>
          <div className="muted">@{post.authorUsername || post.authorId || 'user'} · {post.visibility || 'public'}</div>
          {post.content && <div style={{ marginTop: 8, whiteSpace: 'pre-wrap' }}>{post.content}</div>}

          {orderedMedia.length ? (
            <div style={{ display: 'grid', gap: 10 }}>
              {orderedMedia.map((item, index) =>
                item.type === 'video' ? (
                  <DetailVideo key={`${item.url}-${index}`} src={item.url} />
                ) : (
                  <img
                    key={`${item.url}-${index}`}
                    src={item.url}
                    alt={item.altText || 'image'}
                    loading="lazy"
                    style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', marginTop: 10, display: 'block' }}
                  />
                ),
              )}
            </div>
          ) : post.imageUrl ? (
            <img
              src={resolveMediaUrl(post.imageUrl)}
              alt="image"
              loading="lazy"
              style={{ width: '100%', borderRadius: 14, border: '1px solid var(--line)', marginTop: 10, display: 'block' }}
            />
          ) : null}
        </div>
      )}

      <div className="row" style={{ marginTop: 12 }}>
        <input className="input" style={{ flex: 1 }} placeholder="Write a comment..." value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn ok" onClick={send}>Send</button>
      </div>
      {status && <div className="muted" style={{ marginTop: 8 }}>{status}</div>}
    </div>
  )
}
