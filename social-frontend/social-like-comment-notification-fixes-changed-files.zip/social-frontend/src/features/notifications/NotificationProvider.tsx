import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { useNotificationsApi } from './notifications.api'
import type { NotificationItem } from './notifications.types'
import { useSocket } from '../../state/socket'

function mergeItems(prev: NotificationItem[], incoming: NotificationItem) {
  const next = [incoming, ...prev.filter((item) => item._id !== incoming._id)]
  next.sort((a, b) => new Date(b.lastEventAt || b.createdAt || 0).getTime() - new Date(a.lastEventAt || a.createdAt || 0).getTime())
  return next
}

type Ctx = {
  items: NotificationItem[]
  unreadCount: number
  loading: boolean
  refresh: (onlyUnread?: boolean) => Promise<void>
  markRead: (id: string) => Promise<void>
  markUnread: (id: string) => Promise<void>
  markAllRead: () => Promise<void>
}

const NotificationCtx = createContext<Ctx | null>(null)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const api = useNotificationsApi()
  const { socket } = useSocket()
  const [items, setItems] = useState<NotificationItem[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(async (onlyUnread = false) => {
    setLoading(true)
    try {
      const data = await api.list(onlyUnread)
      setItems(Array.isArray(data.items) ? data.items : [])
      setUnreadCount(Number(data.unreadCount) || 0)
    } finally {
      setLoading(false)
    }
  }, [api])

  useEffect(() => {
    refresh().catch(() => undefined)
  }, [refresh])

  useEffect(() => {
    if (!socket) return

    const onNew = (payload: NotificationItem) => {
      if (!payload?._id) return
      setItems((prev) => mergeItems(prev, payload))
      setUnreadCount((count) => count + (payload.isRead ? 0 : 1))
    }

    const onCount = (payload: { unreadCount?: number }) => {
      setUnreadCount(Number(payload?.unreadCount) || 0)
    }

    socket.on('notification:new', onNew)
    socket.on('notification:count', onCount)

    return () => {
      socket.off('notification:new', onNew)
      socket.off('notification:count', onCount)
    }
  }, [socket])

  const markRead = useCallback(async (id: string) => {
    const item = await api.read(id)
    setItems((prev) => prev.map((entry) => (entry._id === id ? item : entry)))
    setUnreadCount((count) => Math.max(0, count - 1))
  }, [api])

  const markUnread = useCallback(async (id: string) => {
    const item = await api.unread(id)
    setItems((prev) => prev.map((entry) => (entry._id === id ? item : entry)))
    setUnreadCount((count) => count + 1)
  }, [api])

  const markAllRead = useCallback(async () => {
    await api.readAll()
    setItems((prev) => prev.map((item) => ({ ...item, isRead: true, readAt: new Date().toISOString() })))
    setUnreadCount(0)
  }, [api])

  const value = useMemo(() => ({ items, unreadCount, loading, refresh, markRead, markUnread, markAllRead }), [items, unreadCount, loading, refresh, markRead, markUnread, markAllRead])
  return <NotificationCtx.Provider value={value}>{children}</NotificationCtx.Provider>
}

export function useNotifications() {
  const ctx = useContext(NotificationCtx)
  if (!ctx) throw new Error('useNotifications must be used within NotificationProvider')
  return ctx
}
