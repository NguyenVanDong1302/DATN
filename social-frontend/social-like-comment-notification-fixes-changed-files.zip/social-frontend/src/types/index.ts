export type PostMedia = {
  type?: 'image' | 'video' | string
  url?: string
  mimeType?: string
  filename?: string
}

export type Post = {
  _id: string
  authorId?: string
  authorUsername?: string
  content?: string
  imageUrl?: string
  visibility?: 'public' | 'friends' | 'private' | string
  likes?: string[]
  likesCount?: number
  likedByMe?: boolean
  commentsCount?: number
  createdAt?: string
  viewsCount?: number
  media?: PostMedia[]
}

export type PostComment = {
  _id: string
  postId?: string
  parentCommentId?: string | null
  authorId?: string
  authorUsername?: string
  content: string
  likes?: string[]
  likesCount?: number
  likedByMe?: boolean
  createdAt?: string
  updatedAt?: string
}
